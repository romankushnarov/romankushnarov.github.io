

const menuToggle = document.querySelector('#menuToggle');
const mobileMenuToggle = document.querySelector('#mobileMenuToggle');
const mobileMenuToggleClose = document.querySelector("#mobile-nav_cross")


menuToggle.onclick = function(){
  document.querySelector('.mobile-line').classList.toggle('block');
  document.querySelector('.mobile-nav').classList.toggle('block');
  document.querySelector('.mobile-line').classList.toggle('mobile-line-active');
  document.querySelector('.mobile-nav').classList.toggle('mobile-nav-active');
}
